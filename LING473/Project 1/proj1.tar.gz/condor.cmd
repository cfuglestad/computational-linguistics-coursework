executable = run.sh
getenv = true
output = run.out
error = run.error
log = run.log
arguments = "/corpora/LDC/LDC99T42/RAW/parsed/prd/wsj/14"
notification = complete
transfer_executable = false
request_memory = 2*1024
queue
