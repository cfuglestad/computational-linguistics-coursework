
#!/bin/sh

python project_1_script /corpora/LDC/LDC99T42/RAW/parsed/prd/wsj/14

