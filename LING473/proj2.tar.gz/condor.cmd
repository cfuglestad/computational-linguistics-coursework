executable run.sh
getenv = true
output = run.out
error = run.error
log = run.log
arguments = "/corpora/LDC/LDC02T31/nyt/2000"
notification = complete
transfer_executable = false
request_memory = 2*1024
queue
