#!/bin/bash

python project_2.py "$1"
